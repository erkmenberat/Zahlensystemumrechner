﻿namespace Zahlensystemumrechner
{
    partial class FormB
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            menüToolStripMenuItem = new ToolStripMenuItem();
            rechnerToolStripMenuItem = new ToolStripMenuItem();
            umwandlerToolStripMenuItem = new ToolStripMenuItem();
            p_Rechner = new Panel();
            equalsbuttonRechner = new Button();
            label10 = new Label();
            label9 = new Label();
            label5 = new Label();
            label6 = new Label();
            txtRechnerErgebnis = new TextBox();
            txtRechner2 = new TextBox();
            txtRechner1 = new TextBox();
            operatoren = new ComboBox();
            label1 = new Label();
            ZahlensystemBox = new ComboBox();
            p_Umwandler = new Panel();
            equalsbuttonUmwandeln = new Button();
            label11 = new Label();
            label8 = new Label();
            label7 = new Label();
            UmwandelBoxRes = new TextBox();
            UmwandelBox = new TextBox();
            label4 = new Label();
            comboBox2 = new ComboBox();
            p_Deckblatt = new Panel();
            label13 = new Label();
            label12 = new Label();
            menuStrip1.SuspendLayout();
            p_Rechner.SuspendLayout();
            p_Umwandler.SuspendLayout();
            p_Deckblatt.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { menüToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Padding = new Padding(7, 3, 0, 3);
            menuStrip1.Size = new Size(1924, 30);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // menüToolStripMenuItem
            // 
            menüToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { rechnerToolStripMenuItem, umwandlerToolStripMenuItem });
            menüToolStripMenuItem.Name = "menüToolStripMenuItem";
            menüToolStripMenuItem.Size = new Size(60, 24);
            menüToolStripMenuItem.Text = "Menü";
            menüToolStripMenuItem.Click += menüToolStripMenuItem_Click;
            // 
            // rechnerToolStripMenuItem
            // 
            rechnerToolStripMenuItem.Name = "rechnerToolStripMenuItem";
            rechnerToolStripMenuItem.Size = new Size(168, 26);
            rechnerToolStripMenuItem.Text = "Rechner";
            rechnerToolStripMenuItem.Click += rechnerToolStripMenuItem_Click;
            // 
            // umwandlerToolStripMenuItem
            // 
            umwandlerToolStripMenuItem.Name = "umwandlerToolStripMenuItem";
            umwandlerToolStripMenuItem.Size = new Size(168, 26);
            umwandlerToolStripMenuItem.Text = "Umwandler";
            umwandlerToolStripMenuItem.Click += umwandlerToolStripMenuItem_Click;
            // 
            // p_Rechner
            // 
            p_Rechner.Controls.Add(equalsbuttonRechner);
            p_Rechner.Controls.Add(label10);
            p_Rechner.Controls.Add(label9);
            p_Rechner.Controls.Add(label5);
            p_Rechner.Controls.Add(label6);
            p_Rechner.Controls.Add(txtRechnerErgebnis);
            p_Rechner.Controls.Add(txtRechner2);
            p_Rechner.Controls.Add(txtRechner1);
            p_Rechner.Controls.Add(operatoren);
            p_Rechner.Controls.Add(label1);
            p_Rechner.Controls.Add(ZahlensystemBox);
            p_Rechner.Location = new Point(0, 34);
            p_Rechner.Margin = new Padding(3, 4, 3, 4);
            p_Rechner.Name = "p_Rechner";
            p_Rechner.Size = new Size(940, 632);
            p_Rechner.TabIndex = 1;
            p_Rechner.Visible = false;
            // 
            // equalsbuttonRechner
            // 
            equalsbuttonRechner.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            equalsbuttonRechner.Location = new Point(418, 352);
            equalsbuttonRechner.Margin = new Padding(3, 4, 3, 4);
            equalsbuttonRechner.Name = "equalsbuttonRechner";
            equalsbuttonRechner.Size = new Size(62, 48);
            equalsbuttonRechner.TabIndex = 15;
            equalsbuttonRechner.Text = "=";
            equalsbuttonRechner.UseVisualStyleBackColor = true;
            equalsbuttonRechner.Click += equalsbuttonRechner_Click;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label10.Location = new Point(542, 52);
            label10.Name = "label10";
            label10.Size = new Size(205, 62);
            label10.TabIndex = 12;
            label10.Text = "Rechner";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label9.Location = new Point(666, 292);
            label9.Name = "label9";
            label9.Size = new Size(104, 28);
            label9.TabIndex = 11;
            label9.Text = "Ergebnis :";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label5.Location = new Point(155, 501);
            label5.Name = "label5";
            label5.Size = new Size(76, 28);
            label5.TabIndex = 10;
            label5.Text = "Zahl 2:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(155, 212);
            label6.Name = "label6";
            label6.Size = new Size(76, 28);
            label6.TabIndex = 9;
            label6.Text = "Zahl 1:";
            // 
            // txtRechnerErgebnis
            // 
            txtRechnerErgebnis.Font = new Font("Segoe UI", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtRechnerErgebnis.Location = new Point(542, 355);
            txtRechnerErgebnis.Margin = new Padding(3, 4, 3, 4);
            txtRechnerErgebnis.Multiline = true;
            txtRechnerErgebnis.Name = "txtRechnerErgebnis";
            txtRechnerErgebnis.Size = new Size(340, 55);
            txtRechnerErgebnis.TabIndex = 6;
            txtRechnerErgebnis.TextChanged += txtRechnerErgebnis_TextChanged;
            // 
            // txtRechner2
            // 
            txtRechner2.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            txtRechner2.Location = new Point(25, 420);
            txtRechner2.Margin = new Padding(3, 4, 3, 4);
            txtRechner2.Multiline = true;
            txtRechner2.Name = "txtRechner2";
            txtRechner2.Size = new Size(340, 55);
            txtRechner2.TabIndex = 5;
            txtRechner2.TextChanged += txtRechner2_TextChanged;
            // 
            // txtRechner1
            // 
            txtRechner1.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            txtRechner1.Location = new Point(25, 264);
            txtRechner1.Margin = new Padding(3, 4, 3, 4);
            txtRechner1.Multiline = true;
            txtRechner1.Name = "txtRechner1";
            txtRechner1.Size = new Size(340, 55);
            txtRechner1.TabIndex = 4;
            txtRechner1.TextChanged += txtRechner1_TextChanged;
            // 
            // operatoren
            // 
            operatoren.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            operatoren.FormattingEnabled = true;
            operatoren.Items.AddRange(new object[] { "+", "-", "x", "/" });
            operatoren.Location = new Point(163, 352);
            operatoren.Margin = new Padding(3, 4, 3, 4);
            operatoren.Name = "operatoren";
            operatoren.Size = new Size(61, 29);
            operatoren.TabIndex = 3;
            operatoren.SelectedIndexChanged += comboBox2_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(25, 25);
            label1.Name = "label1";
            label1.Size = new Size(290, 23);
            label1.TabIndex = 1;
            label1.Text = "Wählen Sie eine Zahlensystem aus :";
            // 
            // ZahlensystemBox
            // 
            ZahlensystemBox.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            ZahlensystemBox.FormattingEnabled = true;
            ZahlensystemBox.Items.AddRange(new object[] { "Binär", "Oktal", "Dezimal", "Hexadezimal" });
            ZahlensystemBox.Location = new Point(25, 52);
            ZahlensystemBox.Margin = new Padding(3, 4, 3, 4);
            ZahlensystemBox.Name = "ZahlensystemBox";
            ZahlensystemBox.Size = new Size(260, 29);
            ZahlensystemBox.TabIndex = 0;
            ZahlensystemBox.SelectedIndexChanged += ZahlensystemBox_SelectedIndexChanged;
            // 
            // p_Umwandler
            // 
            p_Umwandler.Controls.Add(equalsbuttonUmwandeln);
            p_Umwandler.Controls.Add(label11);
            p_Umwandler.Controls.Add(label8);
            p_Umwandler.Controls.Add(label7);
            p_Umwandler.Controls.Add(UmwandelBoxRes);
            p_Umwandler.Controls.Add(UmwandelBox);
            p_Umwandler.Controls.Add(label4);
            p_Umwandler.Controls.Add(comboBox2);
            p_Umwandler.Location = new Point(0, 687);
            p_Umwandler.Margin = new Padding(3, 4, 3, 4);
            p_Umwandler.Name = "p_Umwandler";
            p_Umwandler.Size = new Size(914, 565);
            p_Umwandler.TabIndex = 3;
            p_Umwandler.Visible = false;
            p_Umwandler.Paint += p_Umwandler_Paint;
            // 
            // equalsbuttonUmwandeln
            // 
            equalsbuttonUmwandeln.Font = new Font("Segoe UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            equalsbuttonUmwandeln.Location = new Point(419, 352);
            equalsbuttonUmwandeln.Margin = new Padding(3, 4, 3, 4);
            equalsbuttonUmwandeln.Name = "equalsbuttonUmwandeln";
            equalsbuttonUmwandeln.Size = new Size(62, 48);
            equalsbuttonUmwandeln.TabIndex = 14;
            equalsbuttonUmwandeln.Text = "=";
            equalsbuttonUmwandeln.UseVisualStyleBackColor = true;
            equalsbuttonUmwandeln.Click += equalsbuttonUmwandeln_Click;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI", 27.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label11.Location = new Point(535, 52);
            label11.Name = "label11";
            label11.Size = new Size(280, 62);
            label11.TabIndex = 13;
            label11.Text = "Umwandler";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label8.Location = new Point(581, 284);
            label8.Name = "label8";
            label8.Size = new Size(229, 28);
            label8.TabIndex = 11;
            label8.Text = " Umgewanderter Zahl :";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label7.Location = new Point(181, 284);
            label7.Name = "label7";
            label7.Size = new Size(64, 28);
            label7.TabIndex = 10;
            label7.Text = "Zahl :";
            // 
            // UmwandelBoxRes
            // 
            UmwandelBoxRes.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            UmwandelBoxRes.Location = new Point(512, 344);
            UmwandelBoxRes.Margin = new Padding(3, 4, 3, 4);
            UmwandelBoxRes.Multiline = true;
            UmwandelBoxRes.Name = "UmwandelBoxRes";
            UmwandelBoxRes.Size = new Size(340, 55);
            UmwandelBoxRes.TabIndex = 6;
            UmwandelBoxRes.TextChanged += UmwandelBoxRes_TextChanged;
            // 
            // UmwandelBox
            // 
            UmwandelBox.Font = new Font("Segoe UI", 18F, FontStyle.Bold);
            UmwandelBox.Location = new Point(49, 344);
            UmwandelBox.Margin = new Padding(3, 4, 3, 4);
            UmwandelBox.Multiline = true;
            UmwandelBox.Name = "UmwandelBox";
            UmwandelBox.Size = new Size(340, 55);
            UmwandelBox.TabIndex = 4;
            UmwandelBox.TextChanged += textBox3_TextChanged;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(25, 25);
            label4.Name = "label4";
            label4.Size = new Size(387, 23);
            label4.TabIndex = 1;
            label4.Text = "Welchen Zahlensystem wollen Sie umwandeln :";
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Binär --> Oktal", "Binär --> Dezimal", "Binär --> Hexadezimal", "Oktal --> Binär", "Oktal --> Dezimal", "Oktal --> Hexadezimal", "Dezimal --> Binär", "Dezimal --> Oktal", "Dezimal --> Hexadezimal", "Hexadezimal --> Binär", "Hexadezimal --> Oktal", "Hexadezimal --> Dezimal" });
            comboBox2.Location = new Point(25, 52);
            comboBox2.Margin = new Padding(3, 4, 3, 4);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(260, 29);
            comboBox2.TabIndex = 0;
            comboBox2.SelectedIndexChanged += comboBox2_SelectedIndexChanged_1;
            // 
            // p_Deckblatt
            // 
            p_Deckblatt.Controls.Add(label13);
            p_Deckblatt.Controls.Add(label12);
            p_Deckblatt.Location = new Point(967, 34);
            p_Deckblatt.Margin = new Padding(3, 4, 3, 4);
            p_Deckblatt.Name = "p_Deckblatt";
            p_Deckblatt.Size = new Size(914, 632);
            p_Deckblatt.TabIndex = 4;
            p_Deckblatt.Visible = false;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(54, 52);
            label13.Name = "label13";
            label13.Size = new Size(215, 20);
            label13.TabIndex = 1;
            label13.Text = "Wählen Sie bitte von Menü aus.";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI", 21.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label12.Location = new Point(322, 187);
            label12.Name = "label12";
            label12.Size = new Size(325, 200);
            label12.TabIndex = 0;
            label12.Text = "--RECHNER--\r\n\r\n\r\n--UMWANDLER--";
            // 
            // FormB
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1924, 1055);
            Controls.Add(p_Deckblatt);
            Controls.Add(p_Umwandler);
            Controls.Add(p_Rechner);
            Controls.Add(menuStrip1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "FormB";
            Text = "Form1";
            Load += FormB_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            p_Rechner.ResumeLayout(false);
            p_Rechner.PerformLayout();
            p_Umwandler.ResumeLayout(false);
            p_Umwandler.PerformLayout();
            p_Deckblatt.ResumeLayout(false);
            p_Deckblatt.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem menüToolStripMenuItem;
        private ToolStripMenuItem rechnerToolStripMenuItem;
        private ToolStripMenuItem umwandlerToolStripMenuItem;
        private Panel p_Rechner;
        private Label label1;
        private ComboBox ZahlensystemBox;
        private ComboBox operatoren;
        private TextBox txtRechnerErgebnis;
        private TextBox txtRechner2;
        private TextBox txtRechner1;
        private Panel p_Umwandler;
        private TextBox UmwandelBoxRes;
        private TextBox UmwandelBox;
        private Label label4;
        private ComboBox comboBox2;
        private Label label5;
        private Label label6;
        private Label label8;
        private Label label7;
        private Label label10;
        private Label label9;
        private Label label11;
        private Panel p_Deckblatt;
        private Label label12;
        private Label label13;
        private Button equalsbuttonRechner;
        private Button equalsbuttonUmwandeln;
    }
}
