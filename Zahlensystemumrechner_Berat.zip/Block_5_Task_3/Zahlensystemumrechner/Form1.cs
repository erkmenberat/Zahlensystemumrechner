    using System;

    namespace Zahlensystemumrechner //Namespace wird erstellt
    {
        public partial class FormB : Form  
        {
            
            int num1, num2, result, zs, op, zwischenergebnis, uwzs;             //
            string resultbinary, hexanum1, hexanum2, hexaresult, umwandeln;    //       Das sind die Variablen den ich in den ganzen Code
            int resultnumber;                                                 //        benutzt habe...
            string numberone;                                                //         


            public FormB()
            {
                InitializeComponent();
            }

            private void rechnerToolStripMenuItem_Click(object sender, EventArgs e) // diese Methode ist dazu da damit ich mehrere Fenster so haben kann wie ich es will 
            {
                p_Rechner.Location = new Point(0, 27);
                p_Umwandler.Location = new Point(1000, 1000);
                p_Rechner.Visible = true;
                p_Umwandler.Visible = false;
                p_Deckblatt.Visible = false;
            }

            private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
            {
                op = comboBox2.SelectedIndex;  // eine Indexz�hler damit wir den Operator von den Dropdown zugreifen k�nnen 
            }
            private void umwandlerToolStripMenuItem_Click(object sender, EventArgs e)// Koordinator von den Fenstern die Sich �ffnen wenn man ausw�hlt ob man Rechnet oder Umrechnet
            {
                p_Umwandler.Location = new Point(0, 27);
                p_Rechner.Location = new Point(1000, 1000);
                p_Umwandler.Visible = true;
                p_Rechner.Visible = false;
                p_Deckblatt.Visible = false;
            }

            private void FormB_Load(object sender, EventArgs e)  // Koordinator von den Fenstern die Sich �ffnen wenn man ausw�hlt ob man Rechnet oder Umrechnet
            {
                this.Size = new Size(940, 632);  // Koordinaten von Fenster die ausgew�hlt wurde
                p_Deckblatt.Location = new Point(0, 27);
                p_Deckblatt.Visible = true;
                p_Umwandler.Visible = false;
                p_Rechner.Visible = false;
            }
            private void ZahlensystemBox_SelectedIndexChanged(object sender, EventArgs e)
            {
                zs = ZahlensystemBox.SelectedIndex; // eine Indexz�hler damit wir den Zahlensystem von den Dropdown zugreifen k�nnen 
            }
            private void equalsbuttonRechner_Click(object sender, EventArgs e)   // diese Methode wird aufgerufen wenn man den button "=" (Rechner) benutzt
            {
                op = operatoren.SelectedIndex;  // eine Indexz�hler damit wir den Operator von den Dropdown zugreifen k�nnen 
                switch (zs)  
                {
                    case 0: // Bin�r Rechner ausgew�hlt 
                        switch (op)  // Operator wird ausgew�hlt 
                        {
                            case 0: // +
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = BinaryToDecimal(num1.ToString());
                                num2 = BinaryToDecimal(num2.ToString());
                                zwischenergebnis = num1 + num2;
                                resultbinary = DecimalToBinary(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 1: // -
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = BinaryToDecimal(num1.ToString());
                                num2 = BinaryToDecimal(num2.ToString());
                                zwischenergebnis = num1 - num2;
                                resultbinary = DecimalToBinary(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 2:  // *
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = BinaryToDecimal(num1.ToString());
                                num2 = BinaryToDecimal(num2.ToString());
                                zwischenergebnis = num1 * num2;
                                resultbinary = DecimalToBinary(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 3:  // /
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = BinaryToDecimal(num1.ToString());
                                num2 = BinaryToDecimal(num2.ToString());
                                zwischenergebnis = num1 / num2;
                                resultbinary = DecimalToBinary(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                        }
                        break;
                    case 1: // Oktal Rechner
                        switch (op)// Operator wird ausgew�hlt 
                        {
                            case 0: // +
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = OctalToDecimal(num1.ToString());
                                num2 = OctalToDecimal(num2.ToString());
                                zwischenergebnis = num1 + num2;
                                resultbinary = DecimalToOctal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 1: // -
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = OctalToDecimal(num1.ToString());
                                num2 = OctalToDecimal(num2.ToString());
                                zwischenergebnis = num1 - num2;
                                resultbinary = DecimalToOctal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 2:  // *
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = OctalToDecimal(num1.ToString());
                                num2 = OctalToDecimal(num2.ToString());
                                zwischenergebnis = num1 * num2;
                                resultbinary = DecimalToOctal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 3: //  /
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                num1 = OctalToDecimal(num1.ToString());
                                num2 = OctalToDecimal(num2.ToString());
                                zwischenergebnis = num1 / num2;
                                resultbinary = DecimalToOctal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                        }
                        break;
                    case 2: // Dezimal Rechner
                        switch (op)// Operator wird ausgew�hlt 
                        {
                            case 0: // +
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                result = num1 + num2;
                                txtRechnerErgebnis.Text = result.ToString();
                                break;
                            case 1:  // -
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                result = num1 - num2;
                                txtRechnerErgebnis.Text = result.ToString();
                                break;
                            case 2: // *
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                result = num1 * num2;
                                txtRechnerErgebnis.Text = result.ToString();
                                break;
                            case 3:  // /
                                num1 = Convert.ToInt32(txtRechner1.Text);
                                num2 = Convert.ToInt32(txtRechner2.Text);
                                result = num1 / num2;
                                txtRechnerErgebnis.Text = result.ToString();
                                break;
                        }
                        break;
                    case 3: // Hexadezimal wurde ausgew�hlt
                        switch (op)// Operator wird ausgew�hlt 
                        {
                            case 0: // +
                                hexanum1 = txtRechner1.Text;
                                hexanum2 = txtRechner2.Text;
                                num1 = HexadecimalToDecimal(hexanum1.ToString());
                                num2 = HexadecimalToDecimal(hexanum2.ToString());
                                zwischenergebnis = num1 + num2;
                                resultbinary = DecimalToHexadecimal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 1:  // -
                                hexanum1 = txtRechner1.Text;
                                hexanum2 = txtRechner2.Text;
                                num1 = HexadecimalToDecimal(hexanum1.ToString());
                                num2 = HexadecimalToDecimal(hexanum2.ToString());
                                zwischenergebnis = num1 - num2;
                                resultbinary = DecimalToHexadecimal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 2:  // *
                                hexanum1 = txtRechner1.Text;
                                hexanum2 = txtRechner2.Text;
                                num1 = HexadecimalToDecimal(hexanum1.ToString());
                                num2 = HexadecimalToDecimal(hexanum2.ToString());
                                zwischenergebnis = num1 * num2;
                                resultbinary = DecimalToHexadecimal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                            case 3:  // /
                                hexanum1 = txtRechner1.Text;
                                hexanum2 = txtRechner2.Text;
                                num1 = HexadecimalToDecimal(hexanum1.ToString());
                                num2 = HexadecimalToDecimal(hexanum2.ToString());
                                zwischenergebnis = num1 / num2;
                                resultbinary = DecimalToHexadecimal(zwischenergebnis);
                                txtRechnerErgebnis.Text = resultbinary.ToString();
                                break;
                        }
                        break;

                }
            }

            public static int BinaryToDecimal(string binary) // Bin�r zu Dezimal  Formel
            {
                int decimalNumber = 0;
                int power = 0;

                for (int i = binary.Length - 1; i >= 0; i--)
                {
                    if (binary[i] == '1')
                    {
                        decimalNumber += (int)Math.Pow(2, power);
                    }
                    power++;
                }

                return decimalNumber;
            }

            public string DecimalToBinary(int decimalNumber)  // Dezimal zu bin�r Formel
            {
                string binaryNumber = string.Empty;

                while (decimalNumber > 0)
                {
                    int remainder = decimalNumber % 2;
                    binaryNumber = remainder.ToString() + binaryNumber;
                    decimalNumber = decimalNumber / 2;
                }

                return binaryNumber;
            }

            public int OctalToDecimal(string octalNumber) // Oktal zu Dezimal formel
            {
                int decimalNumber = 0;
                int power = 0;

                for (int i = octalNumber.Length - 1; i >= 0; i--)
                {
                    decimalNumber += (octalNumber[i] - '0') * (int)Math.Pow(8, power);
                    power++;
                }

                return decimalNumber;
            }

            public string DecimalToOctal(int decimalNumber) //Dezimal zu Oktal formel
            {
                string octalNumber = "";

                while (decimalNumber > 0)
                {
                    int remainder = decimalNumber % 8;
                    octalNumber = remainder.ToString() + octalNumber;
                    decimalNumber /= 8;
                }

                return octalNumber;
            }
            public int HexadecimalToDecimal(string hexadecimalNumber) // Hexadezimal zu Dezimal formel
            {
                int decimalNumber = 0;
                int power = 0;

                for (int i = hexadecimalNumber.Length - 1; i >= 0; i--)
                {
                    int hexadecimalDigit = HexadecimalToDecimal(hexadecimalNumber[i]);
                    decimalNumber += hexadecimalDigit * (int)Math.Pow(16, power);
                    power++;
                }

                return decimalNumber;
            }

            public int HexadecimalToDecimal(char hexadecimalDigit)  // Hexadezimal zu Dezimal formel 2
            {
                switch (hexadecimalDigit)
                {
                    case '0': return 0;
                    case '1': return 1;
                    case '2': return 2;
                    case '3': return 3;
                    case '4': return 4;
                    case '5': return 5;
                    case '6': return 6;
                    case '7': return 7;
                    case '8': return 8;
                    case '9': return 9;
                    case 'A':
                    case 'a': return 10;
                    case 'B':
                    case 'b': return 11;
                    case 'C':
                    case 'c': return 12;
                    case 'D':
                    case 'd': return 13;
                    case 'E':
                    case 'e': return 14;
                    case 'F':
                    case 'f': return 15;
                    default: throw new ArgumentException("Invalid hexadecimal digit: " + hexadecimalDigit);
                }
            }
            public string DecimalToHexadecimal(int decimalNumber)   // Dezimal zu Hexadezimal Formel 
            {
                const string hexDigits = "0123456789ABCDEF";
                string hexNumber = "";

                while (decimalNumber > 0)
                {
                    int remainder = decimalNumber % 16;
                    hexNumber = hexDigits[remainder] + hexNumber;
                    decimalNumber /= 16;
                }

                return hexNumber;
            }

            private void equalsbuttonUmwandeln_Click(object sender, EventArgs e) // eine Methode die Aufgerufen wird wenn man den "=" button dr�ckt(Umrechner)
            {
                switch (uwzs)
                {
                    case 0: // Bin�r zu Oktal
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 2);
                        UmwandelBoxRes.Text = Convert.ToString(resultnumber, 8);
                        break;
                    case 1: // Bin�r zu Dezimal
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 2);
                        UmwandelBoxRes.Text = resultnumber.ToString();
                        break;
                    case 2: // Bin�r zu Hexadecimal 
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 2);
                        UmwandelBoxRes.Text = Convert.ToString(resultnumber, 16);
                        break;
                    case 3: // Oktal zu Bin�r 
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 8);
                        UmwandelBoxRes.Text = Convert.ToString(resultnumber, 2);
                        break;
                    case 4: // Oktal zu Dezimal 
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 8);
                        UmwandelBoxRes.Text = resultnumber.ToString();
                        break;
                    case 5: // Oktal zu Hexadezimal
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 8);
                        UmwandelBoxRes.Text = Convert.ToString(resultnumber, 16);
                        break;
                    case 6: //Decimal to Binary
                        num1 = Convert.ToInt32(UmwandelBox.Text);
                        UmwandelBoxRes.Text = DecimalToBinary(num1);
                        break;
                    case 7: //Decimal to Octale
                        num1 = Convert.ToInt32(UmwandelBox.Text);
                        UmwandelBoxRes.Text = DecimalToOctal(num1);
                        break;
                    case 8: //Decimal to Hexa
                        num1 = Convert.ToInt32(UmwandelBox.Text);
                        UmwandelBoxRes.Text = DecimalToHexadecimal(num1);
                        break;
                    case 9: // Hexadezimal zu Bin�r
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 16);
                        UmwandelBoxRes.Text = Convert.ToString(resultnumber, 2);
                        break;
                    case 10: // Hexadezimal zu Oktal
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 16);
                        UmwandelBoxRes.Text = Convert.ToString(resultnumber, 8);
                        break;
                    case 11: // Hexadezimal zu Dezimal 
                        numberone = UmwandelBox.Text;
                        resultnumber = Convert.ToInt32(numberone, 16);
                        UmwandelBoxRes.Text = resultnumber.ToString();
                        break;


                }
            }

            private void comboBox2_SelectedIndexChanged_1(object sender, EventArgs e)
            {
                uwzs = comboBox2.SelectedIndex; // eine varibale wird benutzt um combobox2 index zu benutzten( Umwandler)
            }
        }
    }
